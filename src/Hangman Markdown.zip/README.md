# Welcome to Hangman
#### Designed by Python group

- Different levels with differnt # of letters in the word.
- Different Difficulties.
- Limited amount of guesses  


## Example  of Game
![Picture of Hangman](https://11points.com/wp-content/uploads/2012/09/dominatehangman-1600.jpg)

Hangman is a game where you guess letters one at a time to try and figure out the word. You have limited amount of guesses, every time you get a letter wrong the water rises until you have been wrong too many times and the water suffocates your player. If you guess the word before the water rises fully, you win!

